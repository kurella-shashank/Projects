package com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.EmployeeDAO;
import com.dto.Employee;


@WebServlet("/LoginServlet") //annotation
public class LoginServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		//reading values from client
		String loginId = request.getParameter("loginId");
		String password = request.getParameter("password");
		
		//Adding LoginId to Session Object
		HttpSession session = request.getSession();
		session.setAttribute("loginId", loginId);
		
		out.print("<html>");
		if(loginId.equalsIgnoreCase("shashank2306") && password.equalsIgnoreCase("password")) {			
			RequestDispatcher rd = request.getRequestDispatcher("HrHomePage.jsp");
			rd.forward(request, response);			
		} else {			
			EmployeeDAO employeeDAO = new EmployeeDAO();			
			Employee employee =  employeeDAO.getEmployee(loginId, password);
			
			if(employee != null) {				
				session.setAttribute("employee", employee);
				
				RequestDispatcher rd = request.getRequestDispatcher("EmpHomePage.jsp");
				rd.forward(request, response);
			} else {
				out.print("<body bgcolor=yellow text=red>");
				out.print("<h1><center>Invalid Credentials..</center></h1>");
				out.print("</body>");
			}			
		}
		out.print("</html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
